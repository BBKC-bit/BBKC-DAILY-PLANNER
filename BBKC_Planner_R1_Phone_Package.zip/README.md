# BBKC Daily Planner — Release 1 (PWA)

This is a browser-based Progressive Web App, not an APK.

## Included
- Four daily segments and task fields WHAT / WHEN / WHERE / HOW
- Task completion checkboxes, date navigation, and missed-task marking when the app is next opened after a date has passed
- Three gratitude entries per day
- Focus timer
- Weekly plan, end-of-day review, calendar/history, streak counter
- Local browser storage and JSON backup import/export
- PWA manifest and offline service worker

## Important limitations
- To install as a PWA from Chrome, host these files on an HTTPS website. Opening `index.html` directly from Downloads does not make it installable as a PWA.
- This package is not an APK and does not include a native Android build.
- Reminder preference and notification permission are included, but this version does not guarantee scheduled notifications when Chrome is closed or the phone restricts background activity.
- Missed tasks are closed when the app next opens after the day has passed, not by a guaranteed exact-midnight Android background job.
- No live JARVIS AI, voice conversation, Instagram/Chess.com usage monitoring, or floating overlay is included.
- Data is stored locally in the browser on this device. Export backups regularly; clearing Chrome site data can erase it.
- This source has not been tested on the user's specific phone or hosted yet.
